-----------------------------------------------------

Merci a vous d'avoir installer mon Fangame Tokyo Revengers

Je ne possede pas les droits du jeu officiel ceci est juste un FanGame.

Pour l'installer vous devrez : 

- Lancer l'installeur
- Accepter les regles d'utilisation 
- Attendre que le téléchargement se finisse
- Profitez et amusez vous

🚧 Je préviens d'avance que quand vous aurez installé le fichier cela vous dira que c'est un VIRUS !

🔑 Le jeu est fait avec un FIW ( Fichiers Incompatibles Windows ) donc votre anti-virus Windows n'acceptera pas un jeu fait avec ceci. 

❓ Alors que faire ?

✅ Vous devrez tout simplement désactiver l'anti-virus windows en marquant "Protection contre les virus et les menaces" puis cliquer sur "Gérer les parametres" puis décocher la case.

-----------------------------------------------------

Thank you for installing my Fangame Tokyo Revengers

I don't own the rights to the official game this is just a FanGame.

To install it you will need:

- Launch the installer
- Accept the rules of use
- Wait for the download to finish
- Enjoy and have fun

🚧 I warn in advance that when you have installed the file it will tell you that it is a VIRUS!
🔑 The game is made with an FIW (Windows Incompatible Files) so your Windows anti-virus will not accept a game made with this. So what to do?

❓ So what to do?

✅ You will simply have to deactivate the windows anti-virus by marking "Protection against viruses and threats" then click on "Manage settings" then uncheck the box.

-----------------------------------------------------

ファンゲームデーモンスレイヤーをインストールしていただきありがとうございます

私は公式ゲームの権利を所有していません。これは単なるファンゲームです。

インストールするには、次のものが必要です。

-インストーラーを起動します
-使用規則を受け入れる
-ダウンロードが完了するのを待ちます
-楽しんで楽しんでください

🚧ファイルをインストールすると、それがウイルスであることが通知されることを事前に警告します。
🔑ゲームはFIW（Windows互換ファイル）で作成されているため、Windowsアンチウイルスはこれで作成されたゲームを受け入れません。 じゃあ何をすればいいの？

❓では、どうすればよいですか？

✅「ウイルスと脅威からの保護」をマークしてWindowsアンチウイルスを非アクティブ化し、「設定の管理」をクリックして、チェックボックスをオフにするだけです。

-----------------------------------------------------


★゜・。。・゜゜・。。・゜☆゜・。。・゜゜・。。・゜★゜・。。・゜゜・。。・゜☆゜・。。・゜゜・。。・゜★

discord.gg/fangame

★゜・。。・゜゜・。。・゜☆゜・。。・゜゜・。。・゜★゜・。。・゜゜・。。・゜☆゜・。。・゜゜・。。・゜★

